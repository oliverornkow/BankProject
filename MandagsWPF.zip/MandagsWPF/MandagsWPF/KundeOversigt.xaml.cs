﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace MandagsWPF
{
    /// <summary>
    /// Interaction logic for KundeOversigt.xaml
    /// </summary>
    public partial class KundeOversigt : Page
    {
        public DataView DV { get; set; }
        
        public KundeOversigt()
        {
            InitializeComponent();
            Oversigt();
        }

        //https://parallelcodes.com/wpf-datagrid-bind-sql-database/
        private void Oversigt()
        {
            //@"Data Source=DESKTOP-CM5VBFO\SQLEXPRESS;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False;Initial Catalog=BGBank";
            String connectionString = @"Data source=(LocalDB)\LocalDB;Initial Catalog=BGBank;Persist Security Info=True;User ID=SQLAdmin;Password=Passw0rd"; 
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand("select fornavn, efternavn, oprettelsesdato, adresse, cpr, adresse.* from Person inner join Adresse on Person.PostNr = Adresse.PostNr", con);
            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            Kundeoversigt_dataGrid.IsReadOnly = true;
            Kundeoversigt_dataGrid.ItemsSource = dt.DefaultView;
            //DV = dt.DefaultView;
            //DataContext = this;
            
            cmd.Dispose();
            con.Close();
        }

        //private void Kundeoversigt_dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    DataGrid gd = (DataGrid)sender;
        //    DataRowView row_selected = gd.SelectedItem as DataRowView;
        //    if(row_selected != null)
        //    {
        //        Konto konto = new Konto();
                
        //        textBox.Text = row_selected["CPR"].ToString();
                
        //    }
        //}

        private void Kundeoversigt_dataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataGrid gd = (DataGrid)sender;
            DataRowView row_selected = gd.SelectedItem as DataRowView;
            Kunde konti = new Kunde();
            konti.Show();
            konti.textBox_fornavn.Text = row_selected["Fornavn"].ToString();
            konti.textBox_efternavn.Text = row_selected["Efternavn"].ToString();
            konti.textBox_oprettelsesdato.Text = row_selected["Oprettelsesdato"].ToString();
            konti.textBox_adresse.Text = row_selected["Adresse"].ToString();
            konti.textBox_cpr.Text = row_selected["CPR"].ToString();
            konti.textBox_postnr.Text = row_selected["PostNr"].ToString();
        }
    }
}
