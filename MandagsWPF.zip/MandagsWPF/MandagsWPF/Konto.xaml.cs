﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace MandagsWPF
{
    /// <summary>
    /// Interaction logic for Konto.xaml
    /// </summary>
    public partial class Konto : Window
    {
        private string connectionString = @"Data Source=(LocalDB)\LocalDB;Initial Catalog=BGBank;Persist Security Info=True;User ID=SQLAdmin;Password=Passw0rd";
        public Konto()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if(Kontotype_comboBox.SelectedItem == null)
            {
                MessageBox.Show("Vælg en kontotype.");
            }
            else if (MessageBox.Show("Vil du fortsætte med at oprette konto?", "Brugeroprettelse", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
            {

            }
            else
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    Kunde cpr = new Kunde();
                    sqlCon.Open();
                    SqlCommand sqlcmd = new SqlCommand("Add_Konto", sqlCon);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@kontotype", Kontotype_comboBox.Text);
                    sqlcmd.Parameters.AddWithValue("@cpr", cpr.textBox_cpr.Text);
                    sqlcmd.ExecuteNonQuery();
                    sqlCon.Close();
                }
                MessageBox.Show("Konto er nu oprettet!");
            }
        }
    }
}
